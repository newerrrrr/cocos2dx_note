#pragma once

int get_huxi(char* cards);
