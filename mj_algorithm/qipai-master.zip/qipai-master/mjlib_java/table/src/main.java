import org.yungege.test.*;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t = new Test();
		t.testOne();
	}

}
