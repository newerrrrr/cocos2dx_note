﻿split 选将拆分法

table 查表法

查表法由网友ak翻译过来
