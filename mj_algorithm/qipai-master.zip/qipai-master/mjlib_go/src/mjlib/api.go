package mjlib

var (
    MTableMgr *TableMgr
    MHuLib *HuLib
)

func Init(){
    MTableMgr = &TableMgr{}
    MTableMgr.Init()
    MHuLib = &HuLib{}
}
