let gen_feng_table = require( './gen_feng_table/gen_feng_table.js' );
let gen_table = require( './gen_table/gen_table.js' );


console.log("开始生产FENG牌...");
gen_feng_table.main();
console.log("生产结束FENG牌...");


console.log("开始生产FENG牌...");
gen_table.main();
console.log("生产结束FENG牌...");


