
-- 生成符合 3*n 和 3*n+2 规则的单个花色(万,筒,条)数据
-- 数据的 key 为 1~9 张牌的个数
-- 比如：1筒2筒3筒3筒3筒3筒6筒7筒8筒2万3万3万3万4万
-- 数字：筒: 1,1,4,0,0,1,1,1,0 得出的数字为114001110
--       万: 0,1,3,1,0,0,0,0,0 得出的数字为013100000

local utils       = require("utils")
local base_split  = require("base_split") 

local table_mgr   = require("table_mgr")
local TType       = table_mgr:getTableTypeEnum()

local path_tbl    = "E:/hlb/work/mj_new/tools/gen_hu_list/tbl_kl/"

local files_config = {}

local MAX_GUI_NUM = 4

--生成通用胡的表数据
table_mgr:init(MAX_GUI_NUM) 
table_mgr:gen_table(false)
table_mgr:gen_table(true)
table_mgr:gen_eye_table(false)
table_mgr:gen_eye_table(true)

local tbl_raw = table_mgr:getTable()

--创建目录
os.execute("mkdir \"" .. path_tbl .. "\"") 


------------------------------------------ split 补充----------------------------------------
--只要大于2的都有可能是将,不管是否能胡
local function find_eye_ex(cards)
    local eyes
    for i = 1, 9 do 
        if cards[i] >= 2 then 
            if nil == eyes then eyes = {} end 
            eyes[i] = true
        end 
    end 
    return eyes 
end 

--将牌切分成两部分,保证前半部分和后半部分都满足3*n,并且可胡, 返回结果为true/false
--可用来判断是否普通胡法(非窟窿胡法)
local function split_two_hu(cards, index)
    if index < 1 or index > 9 then 
        return false 
    end 
    --如果整体上不能胡则返回
    if not base_split.split(cards, 1, 9) then 
        return false 
    end 

    --开始分割成两部分,只要保证其中一部分胡, 则另一部分必定胡
    local sum1 = 0
    local sum2 = 0 
    local tbl_1 = {0, 0, 0, 0, 0, 0, 0, 0, 0}
    for i = 1, 9 do 
        if i < index then 
            tbl_1[i] = cards[i]
            sum1 = sum1 + cards[i] 
        elseif i > index then 
            sum2 = sum2 + cards[i] 
        end 
    end 

    local need_1 = sum1%3 > 0 and 3-sum1%3 or 0 
    local need_2 = sum2%3 > 0 and 3-sum2%3 or 0  
    -- print("sum1, sum2, need_1, need_2=", sum1, sum2, need_1, need_2) 
    if need_1 + need_2 > cards[index] then --超出总张数
        return false 
    end 
    tbl_1[index] = need_1 
    if not base_split.split(tbl_1, 1, index) then 
        return false 
    end 

    return true 
end 

--3*n-1张
local function can_kulong_hu(cards, i)
    local result = false 
    if i >= 3 and i <= 8 then 
        if cards[i-1] > 0 and cards[i] >= 0 and cards[i] < 4 and cards[i+1] > 0 then 
            --要构成窟窿,必须是中间的张数 < 两边的张数
            local count = cards[i] 
            if count >= cards[i-1] or count >= cards[i+1] then 
                return 
            end 
            cards[i-1] = cards[i-1] - count - 1
            cards[i+1] = cards[i+1] - count - 1
            cards[i] = 0 
            if base_split.split(cards, 1, 9) then 
                result = true 
            end 
            cards[i-1] = cards[i-1] + count + 1
            cards[i+1] = cards[i+1] + count + 1 
            cards[i] = count       
        end 
    end 
    return result 
end 

--不带将时查看可以听哪些牌(必须是窟窿胡法,而且不能有普通胡法)
--cards: 3*n-1张卡
local function check_ting(cards)
    local ting_info 

    for i = 1, 9 do 
        if cards[i] < 4 then             
            --检查是否普通胡
            cards[i] = cards[i] + 1 
            if split_two_hu(cards, i) then --如果是普通胡法则直接返回
                return 
            end 
            cards[i] = cards[i] - 1

            if can_kulong_hu(cards, i) then 
                if nil == ting_info then ting_info = {} end 
                table.insert(ting_info, i) 
            end 
        end 
    end 

    return ting_info 
end 


--查看听哪些牌(必须是窟窿胡法,而且不能有普通胡法)
--cards: 3*n+1张卡
local function check_eye_ting(cards)
    local ting_info 

    for k = 1, 9 do 
        if cards[k] < 4 then 
            cards[k] = cards[k] + 1 
            --必须确保在不同将时, 能胡的情况下,必须只能是窟窿胡,只要有一种普通胡法, 则都不能听牌
            local eyes = find_eye_ex(cards)
            if eyes then 
                for i, _ in pairs(eyes) do --查询每一种将的情况
                    --扣除将
                    cards[i] = cards[i] - 2 

                    --检查是否普通胡
                    if split_two_hu(cards, k) then --如果是普通胡法则直接返回
                        return 
                    end 

                    --检查是否窟窿胡
                    cards[k] = cards[k] - 1 
                    if can_kulong_hu(cards, k) then 
                        if k ~= i then --因为如果将和窟窿相同,则可能出现普通胡:如 7889, 摸一张牌8,胡的牌型为 789 88,但是8如果在后面则为普通胡法
                            if nil == ting_info then ting_info = {} end 
                            if nil == ting_info[i] then ting_info[i] = {} end                     
                            table.insert(ting_info[i], k) 
                        end 
                    end 
                    cards[k] = cards[k] + 1 

                    --返还将
                    cards[i] = cards[i] + 2 
                end 
            end 
            cards[k] = cards[k] - 1 
        end 
    end 

    return ting_info
end 

--返回窟窿胡时切割开的牌型组合,仅适合条筒万花色,不包含将
--cards, laiziCards 手牌, 癞子牌, 碎片中癞子用0xff表示, 普通牌用下标表示
local function split_chips(cards, from, to, laiziCards)
    local chips = {}

    if nil == laiziCards then 
        laiziCards = {}
        for i = from, to do
            laiziCards[i] = 0 
        end 
    end 
    local tmp_cards = utils:clone(cards)
    local tmp_laizi = utils:clone(laiziCards)

    for i = from, to do
        local n, m
        local c = tmp_cards[i] + tmp_laizi[i]
        
        if c == 1 or c == 4 then -- 1张牌或4张牌，拆1个顺子
            n = 1
        elseif c == 2 then -- 2张牌，拆两个顺子
            n = 2
        elseif c == 3 then --刻子
            m = 1
        end
        -- print("===i, n, m", i, n, m)
        if n then --拆顺子
            if i + 2 > to then
                return
            end
            local c1 = tmp_cards[i+1]+tmp_laizi[i+1]
            if c1 < n then
                return
            end
            local c2 = tmp_cards[i+2]+tmp_laizi[i+2]
            if c2 < n then
                return
            end

            for k=1, n do 
                local p1 = tmp_cards[i] > 0 and i or 0xff 
                local p2 = tmp_cards[i+1] > 0 and i+1 or 0xff 
                local p3 = tmp_cards[i+2] > 0 and i+2 or 0xff 
                table.insert(chips, {p1, p2, p3})

                if tmp_cards[i] > 0 then 
                    tmp_cards[i] = tmp_cards[i] - 1 
                else 
                    tmp_laizi[i] = tmp_laizi[i] - 1 
                end 
                if tmp_cards[i+1] > 0 then 
                    tmp_cards[i+1] = tmp_cards[i+1] - 1 
                else 
                    tmp_laizi[i+1] = tmp_laizi[i+1] - 1 
                end 
                if tmp_cards[i+2] > 0 then 
                    tmp_cards[i+2] = tmp_cards[i+2] - 1 
                else 
                    tmp_laizi[i+2] = tmp_laizi[i+2] - 1 
                end 
            end 

        elseif m then --拆刻子
            if tmp_cards[i] >= 3 then 
                table.insert(chips, {i, i, i}) 
            elseif tmp_cards[i] >= 2 then 
                table.insert(chips, {i, i, 0xff}) 
            elseif tmp_cards[i] >= 1 then 
                table.insert(chips, {i, 0xff, 0xff}) 
            else 
                table.insert(chips, {0xff, 0xff, 0xff}) 
            end 
        end 
    end 

    return chips 
end 

--切割字牌(东南西北中发白[28~34]), 返回牌型组合,不包含将
--只能是刻子这一种情况; 碎片中癞子用0xff表示, 普通牌用下标表示
local function split_chips_zi(cards, from, to, laiziCards)
    local chips = {}

    if nil == laiziCards then 
        laiziCards = {}
        for i = from, to do
            laiziCards[i] = 0 
        end 
    end 
    local tmp_cards = utils:clone(cards)
    local tmp_laizi = utils:clone(laiziCards)

    for i = from, to do 
        local m 
        local c = tmp_cards[i] + tmp_laizi[i] 
        
        if c == 1 or c == 2 or c == 4 then --不能是顺子 
            return
        elseif c == 3 then --刻子 
            m = 1 
        end 

        if m then 
            if tmp_cards[i] >= 3 then 
                table.insert(chips, {i, i, i}) 
            elseif tmp_cards[i] >= 2 then 
                table.insert(chips, {i, i, 0xff}) 
            elseif tmp_cards[i] >= 1 then 
                table.insert(chips, {i, 0xff, 0xff}) 
            else 
                table.insert(chips, {0xff, 0xff, 0xff}) 
            end 
        end 
    end 

    return chips 
end 





-------------------------------------------开始生成表---------------------------------------

--dump 时允许拆分大文件
local function _dump2(tbl_type, gui_num, fileName, tbl, keyLen)
    local keystr = keyLen == 9 and "[%09d]=%s,\n" or "[%07d]=%s,\n"
    
    --由于有些文件太大,引擎加载会失败, 所以需要拆分成多个文件存放 
    if gui_num >= 0 then 
        if nil == files_config[tbl_type] then files_config[tbl_type] = {} end 
        if nil == files_config[tbl_type][gui_num] then files_config[tbl_type][gui_num] = {} end 
        utils:mergeTblEx(files_config[tbl_type][gui_num], {fileName})
    end 

    local size = 0 
    local file_index = 1 
    local path_name = string.format("%s/%s.lua", path_tbl, fileName) 
    local f = io.open(path_name, "w+")
    f:write("local tbl = {\n")
    for k, v in pairs(tbl) do 
        local str = string.format(keystr, k, utils:tableToStr(v)) 
        f:write(str)

        size = size + string.len(str) 
        if size > 600*1024 then --大于600K时后续内容存到另外文件
            size = 0 
            f:write("}\nreturn tbl\n")
            f:close()

            file_index = file_index + 1
            local name = fileName.."_part" .. file_index
            utils:mergeTblEx(files_config[tbl_type][gui_num], {name})
            path_name = string.format("%s/%s.lua", path_tbl, name) 
            f = io.open(path_name, "w+")
            f:write("local tbl = {\n")
        end 
    end 
    f:write("}\nreturn tbl\n")
    f:close() 
end


--生成带 0 ~ MAX_GUI_NUM 癞子的听牌表
local function gen_laizi_kulong_tbl(eye)
    local tbl = eye and tbl_raw[TType.TTW_Eye] or tbl_raw[TType.TTW_Nor]

    local tmp_tbl = {}

    --1.生成少1张牌(相当于带 0 张癞子)时可以听的窟窿牌. 
    tmp_tbl[0] = {}
    for k, v in pairs(tbl[1]) do 
        local cards = utils:getCardsByKeys(k)
        local info
        if eye then 
            info = check_eye_ting(cards) 
        else 
            info = check_ting(cards) 
        end 
        if info then 
            tmp_tbl[0][k] = info 
        end 
    end 

    --2.生成少n张牌时可以听的牌. 相当于是带n-1个癞子时可以听的牌
    --实现方法:在前面的表的基础上,每一位减去1张,汇总即可
    local function gen_laizi_kl_tbl(level)
        if level <= MAX_GUI_NUM then 
            tmp_tbl[level] = {}
            for k, v in pairs(tmp_tbl[level-1]) do --将前面的表中的每一位的牌数减1, 汇总到新表                                            
                local cards = utils:getCardsByKeys(k) 
                for i = 1, 9 do 
                    if cards[i] > 0 then 
                        cards[i] = cards[i] - 1 

                        local index = utils:getKeyByCards(cards)
                        local t = tmp_tbl[level][index] and utils:clone(tmp_tbl[level][index]) or {} 
                        utils:mergeTblEx(t, v) 
                        tmp_tbl[level][index] = t 

                        cards[i] = cards[i] + 1 
                    end 
                end 
            end 

            gen_laizi_kl_tbl(level+1) 
        end 
    end 
    gen_laizi_kl_tbl(1) 

    local table_type = eye and TType.TTW_Eye or TType.TTW_Nor 
    local file_name = eye and "kl_tbl_eye_" or "kl_tbl_"
    for i = 0, MAX_GUI_NUM do 
        _dump2(table_type, i, file_name..i, tmp_tbl[i], 9)
    end 
end 

--条筒万满牌时判断是否可普通胡的表 
local function gen_full_table() 

    --1.带将的表需要指出将的位置
    for cardkey, _ in pairs(tbl_raw[TType.TTW_Eye][0]) do 
        local eye = {}
        local cards = utils:getCardsByKeys(tonumber(cardkey), 9)
        for i = 1, 9 do 
            if cards[i] >= 2 then 
                cards[i] = cards[i] - 2
                local tmpkey = utils:getKeyByCards(cards, 9) 
                if tmpkey == 0 or tbl_raw[TType.TTW_Nor][0][tmpkey] then 
                    table.insert(eye, i)
                end 
                cards[i] = cards[i] + 2 
            end  
        end 
        tbl_raw[TType.TTW_Eye][0][cardkey].eye = eye 
    end 

    --2.存档生成表 
    _dump2(TType.TTW_Eye, -1, "kl_tbl_eye_none", tbl_raw[TType.TTW_Eye][0], 9)
    _dump2(TType.TTW_Nor, -1, "kl_tbl_none", tbl_raw[TType.TTW_Nor][0], 9)
end 


local function gen_laizi_kulong_zi_tbl()
    for i = 0, MAX_GUI_NUM do
        _dump2(TType.ZI_Nor, i, "zi_table_"..i, tbl_raw[TType.ZI_Nor][i], 7)
        _dump2(TType.ZI_Eye, i, "zi_table_eye_"..i, tbl_raw[TType.ZI_Eye][i], 7) 
    end
end

--字牌满牌时判断是否可普通胡的表
local function gen_full_zi_table() 

    --1.带将的表需要指出将的位置 
    for cardkey, v in pairs(tbl_raw[TType.ZI_Eye][0]) do 
        if type(v) == "table" then 
            local eye = {}
            local cards = utils:getCardsByKeys(tonumber(cardkey), 7)
            for i = 1, 7 do 
                if cards[i] >= 2 then 
                    cards[i] = cards[i] - 2
                    local tmpkey = utils:getKeyByCards(cards, 7) 
                    if tmpkey == 0 or tbl_raw[TType.ZI_Nor][0][tmpkey] then 
                        table.insert(eye, i)
                    end 
                    cards[i] = cards[i] + 2 
                end  
            end 
            tbl_raw[TType.ZI_Eye][0][cardkey].eye = eye 
        end 
    end 
    -- require("log_debug")
    -- dump(tbl_raw[TType.ZI_Eye][0], "===tbl_raw[TType.ZI_Eye][0]")
    --2.存档生成表
    _dump2(TType.ZI_Eye, -1, "zi_table_eye_none", tbl_raw[TType.ZI_Eye][0], 7)
    _dump2(TType.ZI_Nor, -1, "zi_table_none", tbl_raw[TType.ZI_Nor][0], 7) 
end 

--配置文件存档
local function dump_file_config()
    local f = io.open(path_tbl.."/files_config.lua", "w+")
    f:write("local tbl = {\n")
    for k, v in pairs(files_config) do 
        local str = tostring(k).."="..utils:tableToStr(v)..",\n"
        f:write(str)
    end 
    f:write("}\nreturn tbl\n")
    f:close()       
end 

function gen_kulong_tbl() 
    gen_laizi_kulong_tbl(false) 
    gen_laizi_kulong_tbl(true)  
    gen_full_table() 

    gen_laizi_kulong_zi_tbl()
    gen_full_zi_table()

    dump_file_config()
end 

gen_kulong_tbl() 
