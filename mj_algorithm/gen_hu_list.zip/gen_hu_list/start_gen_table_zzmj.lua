
local utils       = require("utils")
local table_mgr   = require("table_mgr")

local TType       = table_mgr:getTableTypeEnum()

local path_tbl    = "E:/hlb/work/mj_new/tools/gen_hu_list/tbl/"
local path_tbl_py = "E:/hlb/work/mj_new/tools/gen_hu_list/tbl_python/"
 

local MAX_GUI_NUM = 8

--生成表数据
table_mgr:init(MAX_GUI_NUM) 
table_mgr:gen_table(false)
table_mgr:gen_table(true)
table_mgr:gen_eye_table(false)
table_mgr:gen_eye_table(true)

local tbl = table_mgr:getTable()

--创建目录
os.execute("mkdir \"" .. path_tbl .. "\"")
os.execute("mkdir \"" .. path_tbl_py .. "\"")


local function getFileName(tttype, guiNum, ext)
    local name 
    local sfx = ext or ".lua"
    if tttype == TType.TTW_Nor then 
        name = string.format("table_%d", guiNum) .. sfx

    elseif tttype == TType.TTW_Eye then 
        name = string.format("table_eye_%d", guiNum) .. sfx 

    elseif tttype == TType.ZI_Nor then 
        name = string.format("zi_table_%d", guiNum) .. sfx

    elseif tttype == TType.ZI_Eye then 
        name = string.format("zi_table_eye_%d", guiNum) ..sfx 
    end  

    return name 
end 

--仅存储数组的下标到文本中, 供服务器 python 加载
local function dump_keys(file, tbl, keyLen)
    print("file path:", file)
    if nil == tbl then return end 

    local keystr = keyLen == 9 and "%09d\n" or "%07d\n"

    local f = io.open(file, "w+")
    for k, v in pairs(tbl) do 
        local str = string.format(keystr, k) 
        f:write(str)
    end
    f:close() 
end 

local function dump_key_value(file, tbl, keyLen)
    print("file path:", file)
    local keystr = keyLen == 9 and "[%09d]=%s,\n" or "[%07d]=%s,\n"

    local f = io.open(file, "w+")
    f:write("local tbl = {\n")
    for k, v in pairs(tbl) do 
        local str = string.format(keystr, k, utils:tableToStr(v)) 
        f:write(str)
    end
    f:write("}\nreturn tbl\n")
    f:close() 
end 

--将所有表中的数组 key, value 中的value由原来的 {} 改为 1, 以减少文件大小
local function gen_table_zzmj()
    for _ttype, t in pairs(tbl) do 
        for i = 0, MAX_GUI_NUM do
            for k, v in pairs(t[i]) do 
                t[i][k] = 1
            end 
            local path = path_tbl .. getFileName(_ttype, i, ".lua")
            local keyLen = 9 
            if _ttype == TType.ZI_Nor or _ttype == TType.ZI_Eye then 
                keyLen = 7 
            end 
            dump_key_value(path, t[i], keyLen)
        end 
    end 
end 

--将所有表中的数据 key 保存到文本中
local function gen_table_zzmj_python()
    for _ttype, t in pairs(tbl) do 
        for i = 0, MAX_GUI_NUM do 
            local path = path_tbl_py .. getFileName(_ttype, i, ".txt")
            local keyLen = 9 
            if _ttype == TType.ZI_Nor or _ttype == TType.ZI_Eye then 
                keyLen = 7 
            end 
            dump_keys(path, t[i], keyLen)
        end 
    end 
end 

gen_table_zzmj()
gen_table_zzmj_python()
