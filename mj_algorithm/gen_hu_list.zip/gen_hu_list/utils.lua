
local M = {}


function M:toStringEx(value)
    if type(value)=='table' then
       return M:tableToStr(value)
    elseif type(value)=='string' then
        return "\""..value.."\""
    else
       return tostring(value)
    end
end

--生成lua的数据表 
function M:tableToStr(t)
    if t == nil then 
        return "" 
    end

    if type(t) == "number" then 
        return tonumber(t)
    end 

    local retstr= "{"

    local count = 0 
    for k, v in pairs(t) do 
        count = count + 1 
    end 
    local isOrdered = count == #t --如果从数字下标1,2,...顺序排列则转化成子串时不显示下标

    local i = 1
    for key,value in pairs(t) do
        local signal = ","
        if i==1 then
          signal = ""
        end

        if key == i then
            if isOrdered then 
                retstr = retstr..signal..M:toStringEx(value) 
            else 
                retstr = retstr..signal..'['..M:toStringEx(key).."]="..M:toStringEx(value) 
            end 
        else
            if type(key)=='number' or type(key) == 'string' then
                retstr = retstr..signal..'['..M:toStringEx(key).."]="..M:toStringEx(value) 
            else
                if type(key)=='userdata' then
                    retstr = retstr..signal.."*s"..M:tableToStr(getmetatable(key)).."*e".."="..M:toStringEx(value)
                else
                    retstr = retstr..signal..key.."="..M:toStringEx(value)
                end
            end
        end

        i = i+1
    end

    retstr = retstr.."}"
    return retstr
end

--tbl_2 合并到 tbl_1 (数组key不带nil)
function M:mergeTbl(tbl_1, tbl_2)
    for _, v in pairs(tbl_2) do 
        local found = false 
        for _, p in pairs(tbl_1) do 
            if p == v then 
                found = true 
                break 
            end 
        end 

        if not found then 
            table.insert(tbl_1, v)
        end 
    end 
end 

--tbl_2 合并到 tbl_1(数组key可带nil)
function M:mergeTblEx(tbl_1, tbl_2) 
    for k, v in pairs(tbl_2) do 
        if nil == tbl_1[k] then 
            tbl_1[k] = v 
        else 
            if type(v) == "table" and type(tbl_1[k]) == "table" then 
                M:mergeTblEx(tbl_1[k], v)
            else 
                local found = false 
                for _, p in pairs(tbl_1) do 
                    if p == v then 
                        found = true 
                        break 
                    end 
                end 
                if not found then 
                    table.insert(tbl_1, v)
                end 
            end 
        end 
    end 
end

function M:tableAdd(tbl_1, tbl_2)
    for k, v in pairs(tbl_2) do 
        tbl_1[k] = tbl_1[k] + v 
    end 
end 

function M:tableRec(tbl_1, tbl_2)
    for k, v in pairs(tbl_2) do 
        tbl_1[k] = tbl_1[k] - v 
    end 
end 

function M:inTable(tbl, val)
    for k, v in pairs(tbl) do 
        if v == val then 
            return true 
        end 
    end 
    return false 
end 

function M:copy(cards)
    local tbl = {}
    for k, v in pairs(cards) do 
        tbl[k] = v 
    end 
    return tbl 
end 

function M:clone(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local newObject = {}
        lookup_table[object] = newObject
        for key, value in pairs(object) do
            newObject[_copy(key)] = _copy(value)
        end
        return setmetatable(newObject, getmetatable(object))
    end
    return _copy(object)
end

--将花色牌数组转化为数字
function M:getKeyByCards(cards, keylen)
    local key = 0
    keylen = keylen or 9 
    for i=1, keylen do    --将9张牌的牌数拼成10进制的key
        key = key*10 + cards[i]
    end 
    return key 
end 

--将数字转化为花色牌数组
function M:getCardsByKeys(key, keylen)
    local cards = {}
    keylen = keylen or 9 
    for i = keylen, 1, -1 do 
        cards[i] = key%10
        key = math.floor(key/10)
    end 
    return cards 
end 

return M 
