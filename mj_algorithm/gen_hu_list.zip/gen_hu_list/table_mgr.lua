

local M = {
    tbl          = {},  
    files_config = {}   --用于将大文件拆分成小文件, 记录各个文件名
}

local TType = {
    TTW_Nor = 1,    --条同万,不带将
    TTW_Eye = 2,    --条同万,带将
    ZI_Nor  = 3,    --字牌,不带将
    ZI_Eye  = 4,    --字牌,带将
} 

local gui_tested     = {}
local gui_eye_tested = {}

local MAX_GUI_NUM

local path_tbl    = "E:/hlb/work/mj_new/tools/gen_hu_list/tbl"
local base_split  = require("base_split") 
local utils       = require("utils")
require("log_debug")


function M:init(guiNumMax) 
    MAX_GUI_NUM = guiNumMax or 4 
    
    for _, v in pairs(TType) do 
        self.tbl[v]          = {} 
        self.files_config[v] = {} 

        for i = 0, MAX_GUI_NUM do 
            self.tbl[v][i] = {} 
        end 
    end 
end 

function M:init_test()
    for i = 0, MAX_GUI_NUM do
        gui_tested[i]     = {}
        gui_eye_tested[i] = {}
    end
end 

-- 将经过检测并满足要求的key放到对应的表中
function M:add(key, gui_num, eye, isZi)
    if isZi then
        if eye then
            self.tbl[TType.ZI_Eye][gui_num][key] = {}
        else
            self.tbl[TType.ZI_Nor][gui_num][key] = {}
        end
    else
        if eye then
            self.tbl[TType.TTW_Eye][gui_num][key] = {}
        else
            self.tbl[TType.TTW_Nor][gui_num][key] = {}
        end 
    end
end 

-- 检查当前牌是否合法(不超出4张), 如果合法则加入到表中
local function check_add(cards, gui_num, eye, isZi)
    local len = isZi and 7 or 9 
    
    local key = 0
    for i = 1, len do    --将9张牌的牌数拼成10进制的key
        key = key * 10 + cards[i]
    end

    if key == 0 then
        return false
    end

    --是否已经检测过
    local m
    if not eye then 
        m = gui_tested[gui_num]
    else
        m = gui_eye_tested[gui_num]
    end
    if m[key] then --如果已经检测过则返回
        return false
    end
    m[key] = true

    for i = 1, len do
        if cards[i] > 4 then --超过4张则非法, 不保存到表中, 直接返回true以便继续生成带癞子的数据表
            return true
        end
    end
    M:add(key, gui_num, eye, isZi) --保存到到表中

    return true
end

-- 检测当前组合下不同鬼牌数时是否满足要求
-- gui_num: 鬼的个数, 对应不同的表
local function parse_table_sub(cards, gui_num, eye, isZi)
    local len = isZi and 7 or 9 

    for i = 1, len do
        repeat
            if cards[i] == 0 then --跳过张数为0的项, 继续检测下一项
                break
            end

            cards[i] = cards[i] - 1 --减少一张, 相当于用一个癞子来代替

            if not check_add(cards, gui_num, eye, isZi) then --如果不满足则恢复牌的个数再检测下一项
                cards[i] = cards[i] + 1
                break
            end
            if gui_num < MAX_GUI_NUM then --继续检测鬼牌数+1时, 最多支持 MAX_GUI_NUM 个癞子
                parse_table_sub(cards, gui_num + 1, eye, isZi) 
            end

            cards[i] = cards[i] + 1 --恢复牌的张数 
        until(true)
    end
end

-- 检查单花色的9张牌是否符合 3*n 或者 3*n+2 模式, 如果符合, 则继续检查带有不同鬼牌(癞子)的情况
-- eye：是否带将
local function parse_table(cards, eye, isZi) 
    if not check_add(cards, 0, eye, isZi) then --不带癞子时满牌胡
        return
    end
    parse_table_sub(cards, 1, eye, isZi) --在前面基础上继续检测癞子数为 1 ~ MAX_GUI_NUM 时的情况
end

-- (条筒万)加入顺子和刻子所有组合
local function gen_table_sub(t, level, eye)
    for j = 1, 16 do --9类刻子+7类顺子
        repeat
            if j <= 9 then --检查1-9都是刻子的情况
                if t[j] > 3 then
                    break
                end
                t[j] = t[j] + 3

            elseif j <= 16 then --检查顺子的情况
                local index = j - 9
                if t[index] >= 4 or t[index+1] >= 4 or t[index+2] >= 4 then
                    break
                end
                t[index] = t[index] + 1
                t[index + 1] = t[index + 1] + 1
                t[index + 2] = t[index + 2] + 1
            end

            parse_table(t, eye, false) --检测加入项后是否合法, 如果合法则同时检测不同癞子数时的情况
            if level < 4 then --最多加入4组
                gen_table_sub(t, level + 1, eye)
            end

            --恢复现场 ,防止顺子的情况下会影响下一个j的处理
            if j <= 9 then
                t[j] = t[j] - 3

            elseif j <= 16 then
                local index = j - 9
                t[index] = t[index] - 1
                t[index + 1] = t[index + 1] - 1
                t[index + 2] = t[index + 2] - 1
            end
        until(true)
    end
end

-- (字牌)加入刻子
local function gen_table_sub_zi(cards, level, eye)
    for i = 1, 7 do
        repeat
            if cards[i] > 3 then --不能超过3张
                break
            end
            cards[i] = cards[i] + 3 --加入1个刻子
            parse_table(cards, eye, true)
            if level < 4 then --最多加入4组
                gen_table_sub_zi(cards, level + 1, eye)
            end
            cards[i] = cards[i] - 3
        until(true)
    end
end

-- 生成表数据: 不带将, 癞子数为 0 ~ MAX_GUI_NUM 
function M:gen_table(isZi)
    M:init_test()

    if isZi then 
        local t = {0, 0, 0, 0, 0, 0, 0}
        gen_table_sub_zi(t, 1, false)        
    else 
        local t = {0, 0, 0, 0, 0, 0, 0, 0, 0}
        gen_table_sub(t, 1, false)
    end 
end 

-- 生成表数据: 带将, 癞子数位 0 ~ MAX_GUI_NUM 
function M:gen_eye_table(isZi) 
    M:init_test()

    if isZi then 
        local t = {0, 0, 0, 0, 0, 0, 0}
        for i = 1, 7 do
            t[i] = 2
            parse_table(t, true, true)
            gen_table_sub_zi(t, 1, true)
            t[i] = 0
        end
    else 
        local t = {0, 0, 0, 0, 0, 0, 0, 0, 0}
        for i = 1, 9 do
            t[i] = 2
            parse_table(t, true, false)
            gen_table_sub(t, 1, true)
            t[i] = 0
        end 
    end 
end

function M:gen_table_ex(colMax) 
    local t = {} 
    for i = 1, colMax do 
        t[i] = 0 
    end 

end 

function M:getGuiNumMax()
    return MAX_GUI_NUM 
end 

function M:getTableTypeEnum()
    return TType 
end 

function M:getTable()
    return self.tbl 
end 




























--将数据保存成文件(lua数组文件)
function M:dump_table()
    for i = 0, MAX_GUI_NUM do
        self:_dump(string.format("%s/table_%d.lua", path_tbl, i), self.tbl[TType.TTW_Nor][i], 9)
        self:_dump(string.format("%s/table_eye_%d.lua", path_tbl, i), self.tbl[TType.TTW_Eye][i], 9)
    end
end

function M:dump_zi_table()
    for i = 0, MAX_GUI_NUM do
        self:_dump(string.format("%s/zi_table_%d.lua", path_tbl, i), self.tbl[TType.ZI_Nor][i], 7)
        self:_dump(string.format("%s/zi_table_eye_%d.lua", path_tbl, i), self.tbl[TType.ZI_Eye][i], 7)
    end
end

function M:_dump(file, tbl, keyLen)
    print("file path:", file)
    if nil == tbl then return end 

    local keystr = keyLen == 9 and "[%09d]=%s,\n" or "[%07d]=%s,\n"

    local f = io.open(file, "w+")
    f:write("local tbl = {\n")
    for k, v in pairs(tbl) do 
        local str = string.format(keystr, k, utils:tableToStr(v)) 
        f:write(str)
    end
    f:write("}\nreturn tbl\n")
    f:close() 
end

--dump 时允许拆分大文件
function M:_dump2(tbl_type, gui_num, fileName, tbl, keyLen)
    local keystr = keyLen == 9 and "[%09d]=%s,\n" or "[%07d]=%s,\n"
    
    --由于有些文件太大,引擎加载会失败, 所以需要拆分成多个文件存放 
    if nil == self.files_config[tbl_type][gui_num] then self.files_config[tbl_type][gui_num] = {} end 
    utils:mergeTblEx(self.files_config[tbl_type][gui_num], {fileName})

    local size = 0 
    local file_index = 1 
    local path_name = string.format("%s/%s.lua", path_tbl, fileName) 
    local f = io.open(path_name, "w+")
    f:write("local tbl = {\n")
    for k, v in pairs(tbl) do 
        local str = string.format(keystr, k, utils:tableToStr(v)) 
        f:write(str)
        size = size + string.len(str) 
        if size > 600*1024 then 
            size = 0 
            f:write("}\nreturn tbl\n")
            f:close()

            file_index = file_index + 1
            local name = fileName.."_part" .. file_index
            utils:mergeTblEx(self.files_config[tbl_type][gui_num], {name})
            path_name = string.format("%s/%s.lua", path_tbl, name) 
            f = io.open(path_name, "w+")
            f:write("local tbl = {\n")
        end 
    end
    f:write("}\nreturn tbl\n")
    f:close() 
end

--配置文件存档
function M:dump_file_config()
    local f = io.open(path_tbl.."/files_config.lua", "w+")
    f:write("local tbl = {\n")
    for k, v in pairs(self.files_config) do 
        local str = tostring(k).."="..utils:tableToStr(v)..",\n"
        f:write(str)
    end 
    f:write("}\nreturn tbl\n")
    f:close()       
end 



--------------------------------------------------------- by hlb for :窟窿麻将 ------------------------------------------------

--生成带 0 ~ MAX_GUI_NUM 癞子的听牌表
function M:gen_laizi_kulong_tbl(eye)
    local tbl = eye and self.tbl[TType.TTW_Eye] or self.tbl[TType.TTW_Nor]

    local tmp_tbl = {}

    --1.生成少1张牌(相当于带 0 张癞子)时可以听的窟窿牌. 
    tmp_tbl[0] = {}
    for k, v in pairs(tbl[1]) do 
        local cards = utils:getCardsByKeys(k)
        local info
        if eye then 
            info = base_split.check_eye_ting(cards) 
        else 
            info = base_split.check_ting(cards) 
        end 
        if info then 
            tmp_tbl[0][k] = info 
        end 
    end 

    --2.生成少n张牌时可以听的牌. 相当于是带n-1个癞子时可以听的牌
    --实现方法:在前面的表的基础上,每一位减去1张,汇总即可
    local function gen_laizi_kl_tbl(level)
        if level <= MAX_GUI_NUM then 
            tmp_tbl[level] = {}
            for k, v in pairs(tmp_tbl[level-1]) do --将前面的表中的每一位的牌数减1, 汇总到新表                                            
                local cards = utils:getCardsByKeys(k) 
                for i = 1, 9 do 
                    if cards[i] > 0 then 
                        cards[i] = cards[i] - 1 

                        local index = utils:getKeyByCards(cards)
                        local t = tmp_tbl[level][index] and utils:clone(tmp_tbl[level][index]) or {} 
                        utils:mergeTblEx(t, v) 
                        tmp_tbl[level][index] = t 

                        cards[i] = cards[i] + 1 
                    end 
                end 
            end 

            gen_laizi_kl_tbl(level+1) 
        end 
    end 
    gen_laizi_kl_tbl(1) 

    local table_type = eye and TType.TTW_Eye or TType.TTW_Nor 
    local file_name = eye and "kl_tbl_eye_" or "kl_tbl_"
    for i = 0, MAX_GUI_NUM do 
        self:_dump2(table_type, i, file_name..i, tmp_tbl[i], 9)
    end 
end 

--条筒万满牌时判断是否可普通胡的表 
function M:gen_full_table() 

    --1.带将的表需要指出将的位置
    for cardkey, _ in pairs(self.tbl[TType.TTW_Eye][0]) do 
        local eye = {}
        local cards = utils:getCardsByKeys(tonumber(cardkey), 9)
        for i = 1, 9 do 
            if cards[i] >= 2 then 
                cards[i] = cards[i] - 2
                local tmpkey = utils:getKeyByCards(cards, 9) 
                if tmpkey == 0 or self.tbl[TType.TTW_Nor][0][tmpkey] then 
                    table.insert(eye, i)
                end 
                cards[i] = cards[i] + 2 
            end  
        end 
        self.tbl[TType.TTW_Eye][0][cardkey].eye = eye 
    end 

    --2.存档生成表
    self:_dump(string.format("%s/%s", path_tbl, "tbl_eye_none.lua"), self.tbl[TType.TTW_Eye][0], 9)
    self:_dump(string.format("%s/%s", path_tbl, "tbl_none.lua"), self.tbl[TType.TTW_Nor][0], 9)
end 

--字牌满牌时判断是否可普通胡的表
function M:gen_full_zi_table() 

    --1.带将的表需要指出将的位置 
    for cardkey, v in pairs(self.tbl[TType.ZI_Eye][0]) do 
        if type(v) == "table" then 
            local eye = {}
            local cards = utils:getCardsByKeys(tonumber(cardkey), 7)
            for i = 1, 7 do 
                if cards[i] >= 2 then 
                    cards[i] = cards[i] - 2
                    local tmpkey = utils:getKeyByCards(cards, 7) 
                    if tmpkey == 0 or self.tbl[TType.ZI_Nor][0][tmpkey] then 
                        table.insert(eye, i)
                    end 
                    cards[i] = cards[i] + 2 
                end  
            end 
            self.tbl[TType.ZI_Eye][0][cardkey].eye = eye 
        end 
    end 

    --2.存档生成表
    self:_dump(string.format("%s/%s", path_tbl, "zi_table_eye_none.lua"), self.tbl[TType.ZI_Eye][0], 7)
    self:_dump(string.format("%s/%s", path_tbl, "zi_table_none.lua"), self.tbl[TType.ZI_Nor][0], 7)
end 

function M:gen_kulong_tbl() 
    M:gen_laizi_kulong_tbl(false) 
    M:gen_laizi_kulong_tbl(true)  
    M:gen_full_table() 
end 


--------------------------------------------------------- by hlb for :郑州麻将 ------------------------------------------------
--将数据保存成文件(lua数组文件)
function M:dump_table_zzmj() 
    for i = 0, MAX_GUI_NUM do
        --将数组下标对应的值由 {} 改为 1, 减少文件大小
        for k, v in pairs(self.tbl[TType.TTW_Nor][i]) do 
            self.tbl[TType.TTW_Nor][i][k] = 1
        end 
        for k, v in pairs(self.tbl[TType.TTW_Eye][i]) do 
            self.tbl[TType.TTW_Eye][i][k] = 1
        end 
        self:_dump(string.format("%s/table_%d.lua", path_tbl, i), self.tbl[TType.TTW_Nor][i], 9)
        self:_dump(string.format("%s/table_eye_%d.lua", path_tbl, i), self.tbl[TType.TTW_Eye][i], 9)
    end
end

--仅存储数组的下标到文本中, 供服务器 python 加载
function M:dump_table_zzmj_keys() 

    local function dump(file, tbl, keyLen)
        print("file path:", file)
        if nil == tbl then return end 

        local keystr = keyLen == 9 and "%09d\n" or "%07d\n"

        local f = io.open(file, "w+")
        for k, v in pairs(tbl) do 
            local str = string.format(keystr, k) 
            f:write(str)
        end
        f:close() 
    end 

    for i = 0, MAX_GUI_NUM do
        dump(string.format("%s/table_%d.txt", path_tbl, i), self.tbl[TType.TTW_Nor][i], 9)
        dump(string.format("%s/table_eye_%d.txt", path_tbl, i), self.tbl[TType.TTW_Eye][i], 9)
    end
end

return M
