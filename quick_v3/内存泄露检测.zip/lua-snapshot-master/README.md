lua-snapshot
============

Make a snapshot for lua state to detect memory leaks.

See dump.lua for example.

Build
=====

make linux 

or 

make mingw (in windows)



