//
//  AppDelegate.h
//  ipatestDemo
//
//  Created by zhu on 16/6/23.
//  Copyright © 2016年 张高杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

