
//
//  AppDelegate.m
//  ipatestDemo
//
//  Created by zhu on 16/6/23.
//  Copyright © 2016年 张高杰. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import <YLSDK/YLSDK.h>
@interface AppDelegate ()


@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:
        (NSDictionary *)launchOptions {
//    [UIApplication sharedApplication].statusBarHidden = true;
    //初始化SDK,传入游戏信息
    GameAppInfo *game = [[GameAppInfo alloc] init];
    game.gameId = @"32";//应用ID
    game.gameName = @"test";//应用名称
    game.gameAppId = @"6AE25A7FACBE8BA76";//应用Appid
    game.promoteId = @"14";//推广ID
    game.promoteAccount = @"1YXtest1";//推广名称
    game.is_test = @"1";//是否测试，0 正式（提审）版 |  1 测试版
    //------------此处trackKey要替换为相应的热云key----------------------------------
    //------------创建角色调用[[YLApi YL_sharedInstance] YL_createRoleSuccess]方法-------------------
    [[YLApi YL_sharedInstance] YL_setYLApiWithInfo:game trackKey:@"677a0126e83ea2a6f2a86185c53f6962" completion:^(NSDictionary *resultDic) {
        NSLog(@"[init] resultDic:%@",resultDic);
        NSNumber *statusCode = [resultDic objectForKey:@"statusCode"];
        if ([statusCode intValue] == YLINITSuccess) {
            //初始化成功
            //如需自动登录，在此处处理自动登录逻辑
        }
    }];
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    ViewController *vc = [[ViewController alloc] init];
    self.window.rootViewController = vc;
    
    
    //检查漏单的处理回调
    [YLApi YL_sharedInstance].YL_paySuccess = ^(NSDictionary *resultDic){
        NSLog(@"NSDictionaryResultDic = %@", resultDic);
        
        NSNumber *payresult = [resultDic objectForKey:@"payresult"];
        if ([payresult intValue] == YLTreatedOrderSuccess) {
            NSLog(@"支付成功，漏单了");
            //**************为了减少漏单几率，不要在这个回调里面处理加钻逻辑，支付成功我们服务************
            //**************器会通知cp服务器，cp服务器收到通知以后客户端再进行加钻。************
        }
    };
    //退出登录的回调方法,需要在这里处理游戏返回到登录页面的逻辑，如果实现了返回登录页面的逻辑，请记得一定要调用[[YLApi YL_sharedInstance] YL_mcLogout];方法注销账户
    [[YLApi YL_sharedInstance] YL_exitLogin:^(NSDictionary *resultDic) {
        NSLog(@"resultDic:%@",resultDic);
       // [[YLApi YL_sharedInstance] YL_mcLogout]; //如果没有实现了返回登录页面的逻辑，请注释掉此方法
        //下面处理回到游戏登录页面的方法
        
    }];
    return YES;
}
/**
 *  微信支付需要接入这个方法，支付完成后的回调
 *
 */
- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [YLApi YL_ExperimentalWX];
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}



- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    // Saves changes in the application's managed object context before the application terminates.
}

@end
