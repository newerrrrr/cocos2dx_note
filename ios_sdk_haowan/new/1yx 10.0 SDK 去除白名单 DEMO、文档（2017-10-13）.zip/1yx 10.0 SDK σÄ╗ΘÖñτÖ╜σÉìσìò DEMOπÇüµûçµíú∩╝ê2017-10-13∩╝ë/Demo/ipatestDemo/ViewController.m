//
//  ViewController.m
//  ipatestDemo
//
//  Created by zhu on 16/6/23.
//  Copyright © 2016年 张高杰. All rights reserved.
//

#import "ViewController.h"
#import <YLSDK/YLSDK.h>
#import "YXYButton.h"

@interface ViewController ()


@end

@implementation ViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [[self navigationController] setNavigationBarHidden:YES
                                               animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    
    YXYButton *loginBtn = [YXYButton btnWithBeginColor:[self colorWithHexWithLong:0x8ba2eb] endColor:[self colorWithHexWithLong:0xbb80d9]];
    [loginBtn setTitle:@"点击登录" forState:UIControlStateNormal];
    loginBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    
    [loginBtn addTarget:self action:@selector(loginAction) forControlEvents:UIControlEventTouchUpInside];
    loginBtn.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:loginBtn];
    
    YXYButton *payBtn = [YXYButton btnWithBeginColor:[self colorWithHexWithLong:0xf89595] endColor:[self colorWithHexWithLong:0xd980a6]];
    [payBtn setTitle:@"商品" forState:UIControlStateNormal];
    payBtn.backgroundColor = [UIColor yellowColor];
    payBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    [payBtn addTarget:self action:@selector(payAction) forControlEvents:UIControlEventTouchUpInside];
    payBtn.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:payBtn];
    
    
    YXYButton *noLoginBtn = [YXYButton btnWithBeginColor:[self colorWithHexWithLong:0xf2c99d] endColor:[self colorWithHexWithLong:0xe27d75]];
    [noLoginBtn setTitle:@"免登陆按钮" forState:UIControlStateNormal];
    [noLoginBtn setBackgroundColor:[UIColor greenColor]];
    [noLoginBtn addTarget:self action:@selector(autoLoginAction) forControlEvents:UIControlEventTouchUpInside];
    noLoginBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    noLoginBtn.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:noLoginBtn];
    
    
    NSArray <NSLayoutConstraint *> *firstH = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[loginBtn(payBtn)]-0-[payBtn]-0-|" options:0 metrics:nil views:@{@"loginBtn" : loginBtn,@"payBtn" : payBtn}];
    [self.view addConstraints:firstH];
    
    NSArray <NSLayoutConstraint *> *secondH = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[noLoginBtn]-0-|" options:0 metrics:nil views:@{@"noLoginBtn" : noLoginBtn}];
    [self.view addConstraints:secondH];
    
    NSArray <NSLayoutConstraint *> *firstV = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[loginBtn(noLoginBtn)]-0-[noLoginBtn]-0-|" options:0 metrics:nil views:@{@"loginBtn" : loginBtn,@"noLoginBtn" : noLoginBtn}];
    [self.view addConstraints:firstV];
    
    
    NSArray <NSLayoutConstraint *> *secondV = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[payBtn(noLoginBtn)]-0-[noLoginBtn]-0-|" options:0 metrics:nil views:@{@"payBtn" : payBtn,@"noLoginBtn" : noLoginBtn}];
    [self.view addConstraints:secondV];
    
    
}
/**
 *  账号登录
 *  账号登录通过is_test判断正式版、测试版，promoteId和promoteAccount统一填正式推广ID和名称
 */
-(void)loginAction{
    NSLog(@"loginAction");
    [[YLApi YL_sharedInstance] YL_addLoginView:self.view
                                    completion:^(NSDictionary *resultDic) {
        NSLog(@"[showLogin] resultDic = %@", resultDic);
 
        NSNumber *loginresult = [resultDic objectForKey:@"loginresult"];
        if([loginresult intValue] == YLLOGINSuccess){
            NSLog(@"登录成功");
            //----------如需二次验证可向服务端验证uid和token---------
            NSString *SDKuid = [resultDic objectForKey:@"userId"];
            NSString *SDKtoken = [resultDic objectForKey:@"token"];
            //----------玩家游戏信息上报------------------------
            //----------上报触发点：1 登录 | 2 升级 | 3 创建角色 | 4 充值 | 5 退出   【必传参数】
            //---------此处只是在登录的时候演示cpl的接入，一共有5个触发点-----------------
            //----------此处uid为cp后台的uid，不是SDK的uid，请注意-----------------
            [[YLApi YL_sharedInstance] YL_cplPlayerInfo:YL_CreateRoleColl uid:@"1" server_name:@"1"
                                            player_name:@"1" player_level:@"1" ctime:@"1"];
        }
    }];
    
    
}
/**
 *  支付
 */

-(void)payAction{
    
    OrderInfo *orderInfo = [[OrderInfo alloc] init];
    orderInfo.goodsName = @"金币";
    orderInfo.goodsPrice = 1*100;//单位为分
    orderInfo.goodsDesc = @"有了金币就可以买买买了";//商品描述
    orderInfo.extendInfo = @"1234567890";//此字段会透传到游戏服务器，可拼接订单信息和其它信息等
    orderInfo.productId = @"com.anheidiguo.dark";//虚拟商品在APP Store中的ID
    //-------注意：此处需要传入的是区服的名称，而不是区服编号-------------------------
    orderInfo.player_server = @"素月流天";//玩家所在区服名称（跟游戏内显示的区服保持一致）
    orderInfo.player_role = @"小明";// 玩家角色名称
    orderInfo.cp_trade_no = @"201603101021";//CP订单号
    
    [[YLApi YL_sharedInstance] YL_pay:orderInfo completionBlock:^(NSDictionary *resultDic) {
        NSLog(@"[pay] resultDic = %@", resultDic);
        NSNumber *payresult = [resultDic objectForKey:@"payresult"];
        if ([payresult intValue] == YLTreatedOrderSuccess) {
            NSLog(@"支付成功");
            //**************为了减少漏单几率，不要在这个回调里面处理加钻逻辑，支付成功我们服务************
            //**************器会通知cp服务器，cp服务器收到通知以后客户端再进行加钻。************
        }
    }];

    
    
}

/**
 *  一键登录（网游一般用不到这个功能）
 *  一般情况下免登陆和账号注册登陆不是同时存在的，一键登录通过is_test判断正式版、测试版，promoteId和promoteAccount统一填正式推广ID和名称
 */
- (void)autoLoginAction{
    
    [[YLApi YL_sharedInstance] YL_addWithOutLogin:^(NSDictionary *resultDic) {
        NSLog(@"[showLogin] resultDic = %@", resultDic);
        NSString *loginRes = [NSString stringWithFormat:@"%@", [resultDic objectForKey:@"loginresult"]];
        if([@"1" isEqualToString:loginRes]){
            
            NSLog(@"登录成功");
        }
    }];
}
- (UIColor *)colorWithHexWithLong:(long)hexColor
{
    float red = ((float)((hexColor & 0xFF0000) >> 16))/255.0;
    float green = ((float)((hexColor & 0xFF00) >> 8))/255.0;
    float blue = ((float)(hexColor & 0xFF))/255.0;
    
    return [UIColor colorWithRed:red green:green blue:blue alpha:1];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
